sort | gawk -f assign3B.awk - 
